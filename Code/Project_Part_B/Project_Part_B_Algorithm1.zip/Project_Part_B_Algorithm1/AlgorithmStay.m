%Mehnetcan Caniklio�lu 2167963
%Mustafa Serkan �yidemir 2095982
function [dx,dy]=AlgorithmStay(game)
index=floor(sqrt(game.numRooms));       %grid size
[a,b]=game.getPlayerLoc;
[c,d]=game.getZomLoc;
e=game.getZomDist;
switch b~=index
      case 0
        dx=1;
        dy=0;
    case 1
if (a==1)&&(e>2*sqrt(2))
    dx=0;
    dy=0;
elseif (c==3)&&(d==3)
    dx=0;
    dy=1;
else
    dx=1;
    dy=1;
end

end
end