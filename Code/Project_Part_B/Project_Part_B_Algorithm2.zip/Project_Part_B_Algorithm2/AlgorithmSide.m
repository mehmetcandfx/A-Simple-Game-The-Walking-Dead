%Mehnetcan Caniklio�lu 2167963
%Mustafa Serkan �yidemir 2095982
function [dx,dy]=AlgorithmSide(game)
index=floor(sqrt(game.numRooms));       %grid size
[a,b]=game.getPlayerLoc;
[c,d]=game.getZomLoc;
e=game.getZomDist;
if (a==1)&&(b~=index)
    dx=0;dy=1;
elseif (b==index)&&(e>sqrt(5))
 dx=1;dy=0;
elseif (b==index)&&(e<=sqrt(5))&&(e>1)
    dx=0;dy=0;
elseif (d==index)&&(e==1)&&(a<c)
    dx=1;dy=-1;
elseif (d==index)&&(a~=index-1)
    dx=1;dy=0;
elseif (d==index)
    dx=1;dy=1;
end
end