%Mehnetcan Caniklio�lu 2167963
%Mustafa Serkan �yidemir 2095982
close all
clear all
Pairs=[25 100 225;.7 .5 .3];
Data=cell(1,3);
for j=1:3
    a=zeros(100,3);
    tic
for i=1:100
    g=Game3(Pairs(1,j),Pairs(2,j));
    g.run;
    close all
    if g.currentState==3
    a(i,1)=1;
    else
    a(i,1)=0;    
    end
    if g.currentState==3
    a(i,2)=g.steps;a(i,3)=0;
    else
        a(i,2)=0;a(i,3)=g.steps;
    end
    if g.player.getHealth>=0
    a(i,4)=g.player.getHealth;
    else
     a(i,4)=0;
    end
end 
toc
Data{1,j}=a;
end
Number_of_Wins_s=sum(Data{1,1}(:,1));
Number_of_Wins_m=sum(Data{1,2}(:,1));
Number_of_Wins_l=sum(Data{1,3}(:,1));
Avarage_steps_to_win_s=sum(Data{1,1}(:,2))/Number_of_Wins_s;
Avarage_steps_to_win_m=sum(Data{1,2}(:,2))/Number_of_Wins_m;
Avarage_steps_to_win_l=sum(Data{1,3}(:,2))/Number_of_Wins_l;
Avarage_steps_to_lose_s=sum(Data{1,1}(:,3))/(100-Number_of_Wins_s);
Avarage_steps_to_lose_m=sum(Data{1,2}(:,3))/(100-Number_of_Wins_m);
Avarage_steps_to_lose_l=sum(Data{1,3}(:,3))/(100-Number_of_Wins_l);
Avarage_health_to_win_s=sum(Data{1,1}(:,4))/Number_of_Wins_s;
Avarage_health_to_win_m=sum(Data{1,2}(:,4))/Number_of_Wins_m;
Avarage_health_to_win_l=sum(Data{1,3}(:,4))/Number_of_Wins_l;
clear Data i j a g Pairs
