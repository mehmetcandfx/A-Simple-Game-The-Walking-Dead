%Mehnetcan Caniklio�lu 2167963
%Mustafa Serkan �yidemir 2095982
function [dx,dy]=Algorithmdirect(game)
index=floor(sqrt(game.numRooms));       %grid size
[a,b]=game.getPlayerLoc;
[c,d]=game.getZomLoc;
e=game.getZomDist;
if (a==b)&&(a<c)&&(e>2*sqrt(2))
    dx=1;dy=1;
elseif (a==b)&&(a<c)&&(e==2*sqrt(2))
dx=0;dy=0;
elseif (a==b)&&(a<c)&&(e==sqrt(2))
 dx=0;dy=1; 
elseif (a==b-1)&&(b~=index)
    dx=1;dy=1;
else
    dy=0;dx=1;  
end
end